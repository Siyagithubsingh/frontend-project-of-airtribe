<!-- pages/index.vue -->
<template>
    <div class="container">
      <div class="row">
        <div class="col">
          <h2>Not Started ({{ notStartedTasks.length }})</h2>
          <div v-for="task in notStartedTasks" :key="task.id">
            <task :task="task" />
          </div>
          <button @click="addTask('Not Started')">New</button>
        </div>
        <!-- Repeat similar structure for "In Progress" and "Completed" -->
      </div>
    </div>
  </template>
  
  <script>
  import Task from '~/components/Task.vue';
  
  export default {
    components: {
      Task
    },
    data() {
      return {
        tasks: [
          { id: 1, title: 'Task 1', status: 'Not Started', description: '...' },
          // Add more tasks here
        ]
      };
    },
    computed: {
      notStartedTasks() {
        return this.tasks.filter(task => task.status === 'Not Started');
      }
      // Similar computed properties for "In Progress" and "Completed" tasks
    },
    methods: {
      addTask(status) {
        // Logic to add a new task
      }
    }
  };
  </script>
  
  <style scoped>
  /* Page styling */
  </style>
  