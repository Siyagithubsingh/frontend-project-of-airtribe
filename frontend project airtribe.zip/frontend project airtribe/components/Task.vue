<!-- components/Task.vue -->
<template>
    <div class="task">
      <h3>{{ task.title }}</h3>
      <p>Status: {{ task.status }}</p>
      <p>{{ task.description }}</p>
      <!-- Add buttons for editing and deleting tasks -->
    </div>
  </template>
  
  <script>
  export default {
    props: {
      task: Object // Task data passed as a prop
    }
  };
  </script>
  
  <style scoped>
  /* Task styling */
  </style>
  